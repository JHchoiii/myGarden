#!/bin/bash

echo "Do you like an apple?"
read answer

case ${answer^^} in
	YES | Y)
	echo "I like an apple 2";;
	NO | N)
	echo "sry";;
	*)
	echo "OK"
	exit 1;;
esac
exit 0


