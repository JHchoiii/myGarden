while [ 1 ]
do 
	echo hi > a.txt
done
