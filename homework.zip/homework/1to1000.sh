#!/bin/bash

if [ -f temp ]
then
	echo continue
	read index sum < temp
else
	index=1
	sum=0
fi

while [ $index -le 1000  ]
do
	sum=`expr $sum + $index`
	index=`expr $index + 1`

	echo $sum
	sleep 0.01

	echo $index $sum > temp
done

rm temp
