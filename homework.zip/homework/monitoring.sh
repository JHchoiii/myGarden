#!/bin/bash

cpuLimit=5
memLimit=80
diskLimit=90

webhook() {
	curl -H "Content-Type: application/json" -d "{\"text\": \"$1 사용량이 임계치를 초과하였습니다.\"}" https://o365kopo.webhook.office.com/webhookb2/1b9b18ca-bb43-4543-8a65-8f096bbe3415@ad21525c-fc0f-4dbc-a403-67ce00add0e4/IncomingWebhook/9df9e7df320b4343a89ecb79d4f4f90c/e121ce81-9987-4377-b475-fc8910920830

}


while [ 1 ]
do
	cpu=$(top bn1 | sed -n -e '3p' | awk '{print $2}')
	mem=$(top bn1 | sed -n -e '4p' | awk '{printf "%.2f\n", $8 / 915.9 * 100}')
	disk=$(df -h | sed -n -e '3p' | awk '{print $5}' | sed 's/%//')
	echo ==========================
	date
	echo "CPU: $cpu%"
	echo "Memory: $mem%"
	echo "Disk: $disk%"
	echo ==========================

	{
        echo ==========================
	date
        echo "CPU: $cpu%"
        echo "Memory: $mem%"
        echo "Disk: $disk%"
        echo ==========================
	} >> monitor.log


	sleep 0.8

	cpu=$(printf "%.0f\n" $cpu)
	if [ $cpu -gt $cpuLimit ]
	then
		echo "cpu 사용량이 $cpuLimit%를 초과하였습니다" 
		echo "cpu 사용량이 $cpuLimit%를 초과하였습니다" >> monitor.log
		webhook cpu
	fi
	mem=$(printf "%.0f\n" $mem)
        if [ $mem -gt $memLimit ]
        then
                echo "memory 사용량이 $memLimit%를 초과하였습니다"
		echo "memory 사용량이 $memLimit%를 초과하였습니다" >> monitor.log
		webhook memory
        fi
	
	if [ $disk -gt $diskLimit ]
        then
                echo "disk 사용량이 $diskLimit%를 초과하였습니다"
		echo "disk 사용량이 $diskLimit%를 초과하였습니다" >> monitor.log
		webhook disk
        fi

done


